package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import socialnetwork.MessageAlert;
import socialnetwork.domain.Prietenie;
import socialnetwork.domain.Tuple;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;

public class UserController extends Control {
    private UtilizatorService srvU=null;
    private Utilizator U = null;
    private PrietenieService srvP;
    private MessageService srvM;
    private CerereService srvC;

    private CereriUserController cer=null;
    private Stage cerere_stage;
    private AddFriendController add_friend;
    private Stage add_stage;
    private SideBarController sbc;

    public void setSrvU(UtilizatorService srvU)
    {
        System.out.println(242343);
        this.srvU = srvU;
    }

    public void setU(Utilizator U)
    {
        this.U=U;
        modelGrade.setAll(U.getFriends());
        if(cer!=null)
            cer.setUser(U);
    }


    ObservableList<Utilizator> modelGrade = FXCollections.observableArrayList();

    @FXML
    TableColumn<Utilizator, Long> tableColumnId;
    @FXML
    TableColumn<Utilizator, String> tableColumnFirstName;
    @FXML
    TableColumn<Utilizator, String> tableColumnLastName;
    @FXML
    TableView<Utilizator> tableViewFriends;
    @FXML
    TableColumn<Utilizator, Button> tableAction;

    //@FXML
    //TextField textFieldId;

    @FXML
    public void initialize() {
        this.tableColumnId.setCellValueFactory(new PropertyValueFactory<Utilizator , Long>("Id"));
        this.tableColumnFirstName.setCellValueFactory(new PropertyValueFactory<Utilizator , String>("FirstName"));
        this.tableColumnLastName.setCellValueFactory(new PropertyValueFactory<Utilizator , String>("LastName"));
        this.tableAction.setCellValueFactory(new PropertyValueFactory<Utilizator , Button>("DelBtn"));
        tableViewFriends.setItems(modelGrade);
       // textFieldId.textProperty().addListener(c -> handleUser());
        if(U!=null) {
            for (Utilizator f : U.getFriends()) {
                Image image = new Image(getClass().getResourceAsStream("/images/Lx.png"));
                ImageView img = new ImageView(image);
                img.setFitHeight(20);
                img.setFitWidth(20);
                f.getDelBtn().setGraphic(img);
                f.getDelBtn().setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        stergere(f);
                    }
                });
            }

            modelGrade.setAll(U.getFriends());
        }
    }

    /*
    private void handleUser() {
        try
        {
            System.out.println(13123);
            Long id = Long.parseLong(textFieldId.getText());
            Utilizator ut = srvU.findOne(id);
            System.out.println(ut);

            U=ut;
            if(cer!=null)
                cer.setUser(ut);
            modelGrade.setAll(ut.getFriends());
            for(Utilizator f:ut.getFriends())
            {
                Image image = new Image(getClass().getResourceAsStream("/images/Lx.png"));
                ImageView img=new ImageView(image);
                img.setFitHeight(20);
                img.setFitWidth(20);
                f.getDelBtn().setGraphic(img);
                f.getDelBtn().setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        stergere(f);
                    }
                });
            }
            sbc.setId(U.getId());
            if(add_friend!=null)
                add_friend.setUser(ut);

        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }*/

    private void stergere(Utilizator selected) {
        U.removeFriend(selected);
        Prietenie p = new Prietenie();
        p.setId(new Tuple<Long, Long>(U.getId(), selected.getId()));
        srvP.removePrietenie(p);
        modelGrade.setAll(U.getFriends());
        MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "deletion", "prietenie a fost stearsa");

    }

    /*
    public void handleSave(ActionEvent actionEvent) {
    }


    public void handleDelete(ActionEvent actionEvent) {
        try {
            Utilizator selected = (Utilizator) tableViewFriends.getSelectionModel().getSelectedItem();
            System.out.println(selected);   //srvU.delete(selected.getId());
            U.removeFriend(selected);
            Prietenie p = new Prietenie();
            p.setId(new Tuple<Long, Long>(U.getId(), selected.getId()));
            srvP.removePrietenie(p);
            modelGrade.setAll(U.getFriends());
            MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "deletion", "prietenie a fost stearsa");
        }
        catch(Exception e)
        {
            MessageAlert.showErrorMessage(null,"tb selectat utilizatorul si prietenul");
        }
    }*/

    public void setSrvP(PrietenieService srvP) {
        this.srvP = srvP;
    }

    public void setSrv(UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.srvU=srvU;
        this.srvP=srvP;
        this.srvM=srvM;
        this.srvC=srvC;
    }

    /*
    public void handleCereri(ActionEvent actionEvent) {

        if(cer!=null)
        {
            if(cerere_stage.isShowing())
                return;
            cerere_stage.show();
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/CereriUserView.fxml"));
            AnchorPane root = loader.load();

            cerere_stage = new Stage();
            cer = loader.getController();
            cer.setSrv(srvU, srvP, srvM, srvC);


            cerere_stage.setScene(new Scene(root,700,450));
            cerere_stage.setTitle("Cereri");
            cer.setUser(U);
            cerere_stage.show();
            //cerere_stage.show();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }*/

    /*
    public void handleAddFriend(ActionEvent actionEvent) {
        if(add_friend!=null)
        {
            if(add_stage.isShowing())
                return;
            add_stage.show();
            return;
        }

        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/AdaugFriend2.fxml"));
            AnchorPane root = loader.load();

            //cerere_stage.isShowing()
            add_stage = new Stage();
            add_friend = loader.getController();
            add_friend.setPrincipal(this);
            add_friend.setSrv(srvU, srvP, srvM, srvC);


            add_stage.setScene(new Scene(root,700,450));
            add_stage.setTitle("Cereri");
            add_friend.setUser(U);
            add_stage.show();
            //cerere_stage.show();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }*/

    @Override
    public void initial(Utilizator U, UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.U=U;
        this.srvU = srvU;
        this.srvP = srvP;
        this.srvM = srvM;
        this.srvC = srvC;
        initialize();
    }

    @Override
    public void parinte(SideBarController sbc) {
        this.sbc = sbc;
    }
}
