package controller;

import socialnetwork.domain.Utilizator;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;

public abstract class Control {
    public abstract void initial(Utilizator U, UtilizatorService srvU, PrietenieService srvP,
                              MessageService srvM, CerereService srvC);

    public void parinte(SideBarController sbc)
    {}

}
