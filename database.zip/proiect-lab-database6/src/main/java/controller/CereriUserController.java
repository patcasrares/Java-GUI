package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import socialnetwork.domain.Cerere;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;

public class CereriUserController extends Control {
    private  Utilizator U=null;
    private UtilizatorService srvU;
    private PrietenieService srvP;
    private MessageService srvM;
    private CerereService srvC;
    ObservableList<Cerere> modelCereri = FXCollections.observableArrayList();
    @Override
    public void initial(Utilizator U, UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.U=U;
        this.srvU = srvU;
        this.srvP = srvP;
        this.srvM = srvM;
        this.srvC = srvC;
        initialize();
    }

    //private TableView cereri;

    @FXML
    TableColumn<Cerere, Long> Recv;
    @FXML
    TableColumn<Cerere, String> Status;
    @FXML
    TableColumn<Cerere, String> Date;

    @FXML
    TableView<Cerere> cereri;

    public void initialize()
    {
        this.Recv.setCellValueFactory(new PropertyValueFactory<Cerere , Long>("Recv"));
        this.Status.setCellValueFactory(new PropertyValueFactory<Cerere , String>("Status"));
        this.Date.setCellValueFactory(new PropertyValueFactory<Cerere , String>("Date"));

        cereri.setItems(modelCereri);
        if(U!=null)
            modelCereri.setAll(srvC.cereri_trimise(U.getId()));
    }


    public void setSrv(UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.srvU=srvU;
        this.srvP=srvP;
        this.srvM=srvM;
        this.srvC=srvC;

        initialize();
    }

    public void setUser(Utilizator U) {
        this.U=U;
        update();
    }

    private void update() {
        if(U==null)
            return;
        modelCereri.setAll(srvC.cereri_trimise(U.getId()));

    }


}
