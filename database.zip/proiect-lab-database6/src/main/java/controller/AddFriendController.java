package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import socialnetwork.MessageAlert;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class AddFriendController extends Control {
    private Utilizator U ;
    private UtilizatorService srvU;
    private PrietenieService srvP;
    private MessageService srvM;
    private CerereService srvC;

    private UserController principal;

    ObservableList<Utilizator> modelUser = FXCollections.observableArrayList();

    public void setPrincipal(UserController principal)
    {
        this.principal=principal;
    }


    public void setSrv(UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.srvU = srvU;
        this.srvP = srvP;
        this.srvM = srvM;
        this.srvC = srvC;

        tableViewFriends.setItems(modelUser);
        //modelUser.setAll()


    }

    private void add_butoane(List<Utilizator> lst) {
        for(Utilizator f:lst)
        {
            Image image = new Image(getClass().getResourceAsStream("/images/add.png"));
            ImageView img=new ImageView(image);
            img.setFitHeight(20);
            img.setFitWidth(20);
            f.getAddBtn().setGraphic(img);
            f.getAddBtn().setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    add_friend(f);
                }
            });
        }
    }

    private void add_friend(Utilizator selected) {
        try
        {
            boolean b=srvC.adaug(U.getId(), selected.getId());
            if(b==true)
                MessageAlert.showMessage(null, Alert.AlertType.INFORMATION,"add friend","ai acceptat prietenia");
            else
                MessageAlert.showMessage(null,Alert.AlertType.INFORMATION,"add friend","ai trimis cererea");
           // U=srvU.findOne(U.getId());
            //principal.setU(U);
            //modelUser.setAll(U.getFriends());
        }
        catch (Exception e)
        {
            MessageAlert.showErrorMessage(null,e.toString());
            //System.out.println(e);
        }
    }

    private void handlePrieten() {
        Predicate<Utilizator> p1 = ut -> ut.getFirstName().startsWith(First.getText());
        Predicate<Utilizator> p2 = n -> n.getLastName().startsWith(Last.getText());

        List<Utilizator> lst = new ArrayList<>();
        modelUser.setAll(srvU.getAllLst()
                .stream()
                .filter(p1.and(p2))
                .collect(Collectors.toList()));
    }

    public void setUser(Utilizator U) {
        this.U = U;
        System.out.println("setat "+U);

    }

    @FXML
    TextField First;
    @FXML
    TextField Last;

    @FXML
    TableColumn<Utilizator, Long> tableColumnId;
    @FXML
    TableColumn<Utilizator, String> tableColumnFirstName;
    @FXML
    TableColumn<Utilizator, String> tableColumnLastName;
    @FXML
    TableColumn<Utilizator, Button> tableAction;
    @FXML
    TableView<Utilizator> tableViewFriends;

    public void handleAdd(ActionEvent actionEvent) {
        Utilizator selected=(Utilizator) tableViewFriends.getSelectionModel().getSelectedItem();
        //Cerere cerere = new Cerere(U.getId(), selected.getId());
        System.out.println("dfsfgtrgefwbtgrfe");
        try
        {
            boolean b=srvC.adaug(U.getId(), selected.getId());
            if(b==true)
                MessageAlert.showMessage(null, Alert.AlertType.INFORMATION,"add friend","ai acceptat prietenia");
            else
                MessageAlert.showMessage(null,Alert.AlertType.INFORMATION,"add friend","ai trimis cererea");
           // U=srvU.findOne(U.getId());
            //principal.setU(U);
            //modelUser.setAll(U.getFriends());
        }
        catch (Exception e)
        {
            MessageAlert.showErrorMessage(null,e.toString());
            //System.out.println(e);
        }

        //modelUser.setAll(U.getFriends());
    }

    @Override
    public void initial(Utilizator U, UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.U=U;
        this.srvU = srvU;
        this.srvP = srvP;
        this.srvM = srvM;
        this.srvC = srvC;
        tableViewFriends.setItems(modelUser);
        List<Utilizator > lst=srvU.getAllLst();
        System.out.println(lst);

        add_butoane(lst);
        modelUser.setAll(lst);



        First.textProperty().addListener(c -> handlePrieten());
        Last.textProperty().addListener(c -> handlePrieten());

        this.tableColumnId.setCellValueFactory(new PropertyValueFactory<Utilizator , Long>("Id"));
        this.tableColumnFirstName.setCellValueFactory(new PropertyValueFactory<Utilizator , String>("FirstName"));
        this.tableColumnLastName.setCellValueFactory(new PropertyValueFactory<Utilizator , String>("LastName"));
        this.tableAction.setCellValueFactory(new PropertyValueFactory<Utilizator , Button>("AddBtn"));
    }
}
