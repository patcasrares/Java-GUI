package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;

import java.net.URL;
import java.util.ResourceBundle;

public class SideBarController implements Initializable {


    private  Utilizator U;
    @FXML
    private AnchorPane ap;
    @FXML
    private BorderPane bp;
    private UtilizatorService srvU;
    private PrietenieService srvP;
    private CerereService srvC;
    private MessageService srvM;
    private Long id;

    public void sidebar(MouseEvent mouseEvent) {
        //loadPage("/view/sidebar.fxml");
        bp.setCenter(ap);
    }

    private void loadPage(String s) {
        Parent root = null;
        try
        {
            FXMLLoader loader=new FXMLLoader();
            loader.setLocation(getClass().getResource(s));
            
            root = loader.load();
            Control cc = loader.getController();
            cc.parinte(this);

            cc.initial(srvU.findOne(id),srvU,srvP,srvM,srvC);

        }
        catch(Exception e)
        {
            System.out.println(e);
            System.out.println("nu merge");
            System.out.println(e.getStackTrace());
        }
        bp.setCenter(root);
    }

    public void CereriUserView(MouseEvent mouseEvent) {
        loadPage("/view/CereriUserView.fxml");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    public void UserFriends(MouseEvent mouseEvent) {
        loadPage("/view/UserView.fxml");
    }

    public void AddFriends(MouseEvent mouseEvent) {
        loadPage("/view/AdaugFriend.fxml");
    }

    public void initial(Long id, UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.id=id;
        this.srvU = srvU;
        this.srvP = srvP;
        this.srvM = srvM;
        this.srvC = srvC;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

}
