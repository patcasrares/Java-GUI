package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.animation.*;
import javafx.stage.Stage;
import javafx.util.Duration;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;


public class LoginController {

    @FXML
    private Label lbUsername;

    @FXML
    private Label lbPassword;

    @FXML
    private TextField user;

    @FXML
    private PasswordField pass;

    @FXML
    private StackPane rootPane;

    @FXML
    private AnchorPane anchorPane;
    private UtilizatorService srvU;
    private PrietenieService srvP;
    private MessageService srvM;
    private CerereService srvC;

    public void OpenCreateAccount(MouseEvent mouseEvent) throws Exception {

        FXMLLoader loader=new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/Register.fxml"));

        Parent root = loader.load();
        Register register = loader.getController();
        register.initial(srvU,srvP,srvM,srvC);
        Scene loginScene = anchorPane.getScene();
        root.translateYProperty().set(loginScene.getHeight());
        rootPane.getChildren().add(root);
        //rootPane.getChildren().remove(anchorPane);
        Timeline timeline = new Timeline();

        KeyValue keyValue=new KeyValue(root.translateYProperty(),0,Interpolator.EASE_IN);
        KeyFrame keyFrame=new KeyFrame(Duration.seconds(2),keyValue);

        timeline.getKeyFrames().add(keyFrame);


        timeline.play();

        timeline.setOnFinished((ActionEvent event2)->
        {
            rootPane.getChildren().remove(anchorPane);
        });


    }

    public void Loghez(MouseEvent mouseEvent) {
        String utilizator = user.getText();
        String password = pass.getText();

        lbUsername.setText("");
        lbPassword.setText("");


        if(utilizator.equals(""))
        {
            //System.out.println("field gol");
            lbUsername.setText("field gol");
        }

        if(password.equals(""))
        {
            //System.out.println("field gol");
            lbPassword.setText("field gol");

        }

        if(utilizator.equals("")||password.equals(""))
            return;


        Long id=srvU.findByEmail(utilizator);

        if(id==null)
        {
            id=srvU.findByUsername(utilizator);
        }

        if(id==null)
        {
            //System.out.println("nu este acest utilizator");
            lbUsername.setText("nu este acest utilizator");
            return;
        }
        Utilizator ut=srvU.findOne(id);
        if(!ut.getPassword().equals(password))
        {
            //System.out.println("parola incorecta");
            lbPassword.setText("parola incorecta");
            return;
        }
        System.out.println("id ul este "+id);
        creez(id);

    }

    private void creez(Long id) {
        try {
            Stage primaryStage = new Stage();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/sidebar.fxml"));
            Pane root;
            root = loader.load();
            SideBarController sbc = loader.getController();
            sbc.initial(id, srvU, srvP, srvM, srvC);

            //UserController ctrl=loader.getController();
            //ctrl.setSrv(srvU,srvP,srvM,srvC);

            primaryStage.setScene(new Scene(root));
            primaryStage.setTitle("Hello World");
            primaryStage.show();
        }
        catch(Exception e)
        {

        }
    }

    public void initial( UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {

        this.srvU = srvU;
        this.srvP = srvP;
        this.srvM = srvM;
        this.srvC = srvC;
    }
}
