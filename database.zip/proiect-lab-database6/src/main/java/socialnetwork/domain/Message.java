package socialnetwork.domain;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Message extends Entity<Long> {
    private Utilizator from;
    private List<Utilizator> to=new ArrayList<Utilizator>();
    private String message;
    private LocalDateTime data;

    //private Message reply = null;

    public Message(Utilizator from,List<Utilizator> to,String message)
    {
        System.out.println("hgjkl");
        this.from=from;
        this.to=to;
        this.message=message;
        this.data=LocalDateTime.now();
    }

    public Utilizator getFrom()
    {
        return from;
    }

   /* public void setReply(Message reply)
    {
        this.reply=reply;
    }*/

    public Message getReply()
    {
        return null;
    }


    public Message(Utilizator from,List<Utilizator> to,String message,LocalDateTime data)
    {
        this.from=from;
        this.to=to;
        this.message=message;
        this.data=data;
    }

    public LocalDateTime getData()
    {
        return data;
    }


    public List<Utilizator> getTo()
    {
        return to;
    }

    public String getMessage()
    {
        return message;
    }


    @Override
    public String toString() {
        List<Long>lst=new ArrayList<Long>();
        for(Utilizator ut:to)
            lst.add(ut.getId());
        String msg=""+this.getId()+";"+from.getId()+";"+lst+";"+data+";"+message;
        /*if(reply ==  null)
            msg+=";0";
        else
            msg+=";"+reply.getId();*/
        return msg;
    }


}
