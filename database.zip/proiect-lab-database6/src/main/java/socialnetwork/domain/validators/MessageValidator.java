package socialnetwork.domain.validators;

import socialnetwork.domain.Message;
import socialnetwork.domain.Utilizator;

import java.util.List;

public class MessageValidator implements Validator<Message> {
    /*
     *verifica dacaun utilizator(entity) este valid
     * (numele si prenumele sunt siruri nevide de litere care incep cu litera mare)
     * arunca ValidationException in caz contrar
     *  */
    @Override
    public void validate(Message entity) throws ValidationException {
        //TODO: implement method validate

        System.out.println("sdjkoa");
        if(entity.getMessage().equals(""))
            throw new ValidationException("mesajul e vid");

        if(entity.getTo().size()==0)
            throw new ValidationException("un mesaj are nevoie de destinatari");

        if(entity.getReply()==null)
            return;

        List<Utilizator> lst=entity.getReply().getTo();
        int vf=0;
        for(Utilizator ut:lst)
            if(ut.getId()==entity.getFrom().getId())
            {
                vf=1;
                break;
            }
        if(vf==0)
            throw new ValidationException("nu ai primit acest mesaj");

    }
}
