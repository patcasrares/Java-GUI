package socialnetwork.domain.validators;

import socialnetwork.domain.Cerere;

public class CerereValidator implements Validator<Cerere> {
    /*
     *verifica dacaun utilizator(entity) este valid
     * (numele si prenumele sunt siruri nevide de litere care incep cu litera mare)
     * arunca ValidationException in caz contrar
     *  */
    @Override
    public void validate(Cerere entity) throws ValidationException {
        //TODO: implement method validate

        if(entity.getSender()==entity.getRecv())
            throw new ValidationException("nu iti poti trimite singur cerere");

    }
}
