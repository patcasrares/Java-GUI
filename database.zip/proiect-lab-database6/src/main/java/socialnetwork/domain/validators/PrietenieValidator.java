package socialnetwork.domain.validators;

import socialnetwork.domain.Prietenie;
import socialnetwork.domain.Utilizator;

public class PrietenieValidator implements Validator<Prietenie> {

    /**
     * verifica daca o relatie de prietenie este valida
     * (daca are data)
     * arunca exceptie in caz contrat
     * @param entity
     * @throws ValidationException
     */
    @Override
    public void validate(Prietenie entity) throws ValidationException {
        if(entity.getDate()==null)
            throw new ValidationException("tb o data");
    }
}
