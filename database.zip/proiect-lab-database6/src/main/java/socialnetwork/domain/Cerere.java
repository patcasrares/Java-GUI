package socialnetwork.domain;

import java.time.LocalDateTime;

public class Cerere extends Entity<Tuple<Long,Long>> {

    private String status="pending";
    private LocalDateTime date;
    public Cerere(Long id1,Long id2) {
        setId(new Tuple(id1,id2));
        date = LocalDateTime.now();
    }

    public LocalDateTime getDate()
    {
        return date;
    }
    public void setStatus(String status)
    {
        this.status=status;
    }

    public Long getSender()
    {
        return getId().getLeft();
    }

    public Long getRecv()
    {
        return getId().getRight();
    }

    public String getStatus(){return status;}

    public void setDate(LocalDateTime date) {
        this.date=date;
    }
}
