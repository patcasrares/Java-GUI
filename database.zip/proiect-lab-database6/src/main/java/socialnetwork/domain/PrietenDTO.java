package socialnetwork.domain;

import java.time.LocalDateTime;

public class PrietenDTO {
    private Utilizator utilizator;
    private LocalDateTime data;

    public PrietenDTO(Utilizator utilizator,LocalDateTime data)
    {
        this.utilizator = utilizator;
        this.data = data;
    }

    public LocalDateTime getData()
    {
        return data;
    }

    @Override
    public String toString() {
        return ""+utilizator.getId()+" | "+utilizator.getFirstName()+" | "+
                utilizator.getLastName()+" | " + data.toString();
    }

}
