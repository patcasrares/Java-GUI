package socialnetwork;

import socialnetwork.config.ApplicationContext;
import socialnetwork.domain.*;
import socialnetwork.domain.validators.CerereValidator;
import socialnetwork.domain.validators.MessageValidator;
import socialnetwork.domain.validators.PrietenieValidator;
import socialnetwork.domain.validators.UtilizatorValidator;
import socialnetwork.repository.Repository;
import socialnetwork.repository.database.CerereDbRepository;
import socialnetwork.repository.database.MessageDbRepository;
import socialnetwork.repository.database.PrieteniDbRepository;
import socialnetwork.repository.database.UtilizatorDbRepository;
import socialnetwork.repository.file.CerereFile;
import socialnetwork.repository.file.MessageFile;
import socialnetwork.repository.file.PrietenieFile;
import socialnetwork.repository.file.UtilizatorFile;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;
import socialnetwork.ui.Consola;

import java.sql.Connection;
import java.sql.DriverManager;

interface Hidden {
    public int getValue ();
}

class Outer4 {
    public Hidden getInnerInstance(int i) {
        if (i == 11) {
            class BlockInner implements Hidden {
                private int i = 11;
                @Override
                public int getValue() {
                    return i;
                }
            }
            return new BlockInner();
        }
        return null;
    }
}



public class Main {
    public static void main(String[] args) {
        Outer4 out4 = new Outer4();
        System.out.println(out4.getInnerInstance(11).getValue());
        Connection c = null;
        // Class.forName("org.postgresql.Driver");
        try {
            Class.forName("org.postgresql.Driver");
            c = DriverManager
                    .getConnection("jdbc:postgresql://localhost:5432/testdb",
                            "postgres", "mateinfonou");
        } catch (Exception e) {
            System.out.println(e);
        }

        System.out.println("ok");
       final String fileName=ApplicationContext.getPROPERTIES().getProperty("data.socialnetwork.users");
        final String fileName2=ApplicationContext.getPROPERTIES().getProperty("data.socialnetwork.prieteni");
//        //String fileName="data/users.csv";
////        Repository0<Long,Utilizator> userFileRepository = new UtilizatorFile0(fileName
////                , new UtilizatorValidator());
//
        System.out.println("Reading data from file");
        Repository<Long,Utilizator> userFileRepository2 = new UtilizatorFile(fileName
                , new UtilizatorValidator());
        //userFileRepository2.findAll().forEach(x-> System.out.println(x));
//
        System.out.println("Reading data from database");
        final String url = ApplicationContext.getPROPERTIES().getProperty("database.socialnetwork.url");
        final String username= ApplicationContext.getPROPERTIES().getProperty("databse.socialnetwork.username");
        final String pasword= ApplicationContext.getPROPERTIES().getProperty("database.socialnetwork.pasword");
        /*Repository<Long,Utilizator> userFileRepository3 =
                new UtilizatorDbRepository(url,username, pasword,  new UtilizatorValidator());
        Repository<Tuple<Long,Long>,Prietenie> repop2 =
                new PrieteniDbRepository(url,username, pasword,  new PrietenieValidator());*/

        Repository<Tuple<Long,Long>, Prietenie> repop=new PrietenieFile(fileName2,new PrietenieValidator());
        //MessageFile repoM = new MessageFile("data/mesaje.csv",new MessageValidator());


        /*UtilizatorService srvU=new UtilizatorService(userFileRepository3,repop2);
        PrietenieService srvP=new PrietenieService(userFileRepository3,repop2);*/
        //UtilizatorService srv=new UtilizatorService(userFileRepository3,repop2);
        //userFileRepository2.findAll().forEach(x-> System.out.println(x));

        //MessageFile repoM = new MessageFile("data/mesaje.csv",userFileRepository2);
       /* MessageService srvM = new MessageService(repoM,userFileRepository2);
        CerereFile repoC = new CerereFile("data/cereri.csv",new CerereValidator());
        CerereService srvC = new CerereService(userFileRepository2,repop,repoC);
        UtilizatorService srvU=new UtilizatorService(userFileRepository2,repop,repoM,repoC);
        PrietenieService srvP=new PrietenieService(userFileRepository2,repop);*/


       /* Repository<Long,Utilizator> repoU =
                new UtilizatorDbRepository(url,username, pasword,  new UtilizatorValidator());
        Repository<Tuple<Long,Long>,Prietenie> repoP =
                new PrieteniDbRepository(url,username, pasword,  new PrietenieValidator());

        Repository<Long,Message> repoM =
               new MessageDbRepository(url,username, pasword);

        Repository<Tuple<Long,Long>, Cerere> repoC=
                new CerereDbRepository(url,username, pasword);

        UtilizatorService srvU=new UtilizatorService(repoU,repoP,repoM,repoC);
        PrietenieService srvP=new PrietenieService(repoU,repoP);
        MessageService srvM=new MessageService(repoM,repoU);
        CerereService srvC=new CerereService(repoU,repoP,repoC);

        Consola ui=new Consola(srvU,srvP,srvM,srvC);*/
        //ui.run();
        Utilizator ut=new Utilizator("A","B");
        ut.setId(2L);
        //userFileRepository3.delete(2L);
        System.out.println("output din fisier");
        userFileRepository2.findAll().forEach(x-> System.out.println(x));
        System.out.println("");
        System.out.println("output din database");

        //repoU.findAll().forEach(x-> System.out.println(x));
        MainFX gui= new MainFX();
        gui.main(args);

    }
}


