package socialnetwork.service;

import socialnetwork.domain.Cerere;
import socialnetwork.domain.Prietenie;
import socialnetwork.domain.Tuple;
import socialnetwork.domain.Utilizator;
import socialnetwork.domain.validators.CerereValidator;
import socialnetwork.domain.validators.Validator;
import socialnetwork.repository.Repository;
import socialnetwork.repository.file.MessageFile;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CerereService {

    private Repository<Long, Utilizator> repoU;
    private Repository<Tuple<Long,Long>, Prietenie> repoP;
    private Repository<Tuple<Long,Long>, Cerere> repoC;

    private Validator<Cerere> valid=new CerereValidator();

    public CerereService(Repository<Long, Utilizator> repo, Repository<Tuple<Long,Long>, Prietenie> repo2, Repository<Tuple<Long,Long>, Cerere> repo3) {

        this.repoU = repo;
        this.repoP= repo2;
        this.repoC=repo3;
        //relatii();
    }

    public Iterable<Cerere> findAll()
    {
        return repoC.findAll();
    }

    public List<Cerere>cereri_trimise(Long id)
    {
        List<Cerere> lst=new ArrayList<Cerere>();
        Iterable<Cerere>it_c = findAll();
        for(Cerere c:it_c)
            lst.add(c);

        return lst.stream()
                .filter(x->x.getSender().equals(id))
                .collect(Collectors.toList());
    }

    public void request(Long id1,Long id2) throws ServiceException
    {

        Utilizator ut1 = repoU.findOne(id1);
        Utilizator ut2 = repoU.findOne(id2);
        if(ut1==null || ut2==null)
            throw new ServiceException("nu se gasesc ambele id-uri 10");

        Cerere c=new Cerere(id1,id2);
        Cerere d=repoC.findOne(c.getId());

        valid.validate(c);

        if(d!=null) {
            if (d.getStatus().equals("rejected")) {
                d.setStatus("pending");
                repoC.update(d);
                return;
            }
            throw new ServiceException("tb sa astepti raspunsul pt a mai trmite odata ");
        }
        //else
            repoC.save(c);
    }

    public void accepta(Long idS,Tuple<Long,Long> id) throws ServiceException
    {
        if(id.getLeft()>id.getRight())
        {
            Tuple<Long,Long> id2=new Tuple<Long,Long>(id.getRight(),id.getLeft());
            id=id2;
        }
        Cerere c=repoC.findOne(id);
        if(c==null)
            throw new ServiceException("nu este aceata cerere ");
        System.out.println(c.getRecv()+" "+idS);
        if(c.getRecv()!=idS)
            throw new ServiceException("aceasta cerere nu a fost trimisa acestui utilizator ");
        if(repoU.findOne(c.getSender())==null)
            throw new ServiceException("nu mai exista acest sender ");
        Utilizator ut1 = repoU.findOne(c.getSender());
        Utilizator ut2 = repoU.findOne(c.getRecv());
        ut1.addFriend(ut2);
        ut2.addFriend(ut1);

        Prietenie prietenie=new Prietenie();
        prietenie.setId(id);
        repoP.save(prietenie);

        c.setStatus("approved");
        repoC.update(c);
    }

    public void refuza(Long idS,Tuple<Long,Long> id) throws ServiceException
    {
       /* if(id.getLeft()>id.getRight())
        {
            Tuple<Long,Long> id2=new Tuple<Long,Long>(id.getRight(),id.getLeft());
            id=id2;
        }*/
        Cerere c=repoC.findOne(id);
        if(c==null)
            throw new ServiceException("nu este aceata cerere ");

        if(c.getRecv()!=idS)
            throw new ServiceException("aceasta cerere nu a fost trimisa acestui utilizator ");
        if(repoU.findOne(c.getSender())==null)
            throw new ServiceException("nu mai exista acest sender ");
        if(!c.getStatus().equals("pending"))
            throw new ServiceException("utilizatorul a refuzat sau acceptat cererea deja");


        c.setStatus("rejected");
        repoC.update(c);

        //repoC.reload();
    }

    public boolean adaug(Long id1, Long id2) {
        Utilizator ut1 = repoU.findOne(id1);
        Utilizator ut2 = repoU.findOne(id2);
        if(ut1==null || ut2 ==null)
            throw new ServiceException("nu se gasesc ambele id-uri234");
        Tuple<Long,Long>id =new Tuple<Long,Long>(id2,id1);
        Cerere c=repoC.findOne(id);
        if(c!=null) {
            accepta(id1,c.getId());
            return true;
        }

        request(id1,id2);
        //System.out.println("deghjk");
        return false;

    }
}
