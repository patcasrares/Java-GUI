package socialnetwork.service;

import socialnetwork.domain.*;
import socialnetwork.domain.validators.UtilizatorValidator;
import socialnetwork.domain.validators.ValidationException;
import socialnetwork.repository.Repository;
import socialnetwork.repository.file.MessageFile;

import java.util.*;

public class UtilizatorService  {
    private Repository<Long, Utilizator> repo;
    private Repository<Tuple<Long,Long>, Prietenie> repo2;
    private Repository<Long, Message> repo3;
    private int cnt=0;
    private ArrayList<Utilizator> sol=new ArrayList<Utilizator>();
    private UtilizatorValidator valid = new UtilizatorValidator();
    private Repository<Tuple<Long,Long>, Cerere>repo4;
    HashMap<Long,Integer>map=new HashMap<Long,Integer>();

    Set<Tuple<Long,Long> > S=new HashSet<Tuple<Long,Long> >();

    public UtilizatorService(Repository<Long, Utilizator> repo, Repository<Tuple<Long,Long>, Prietenie> repo2,Repository<Long,Message> repo3
    ,Repository<Tuple<Long,Long>, Cerere>repo4) {

        this.repo = repo;
        this.repo2= repo2;
        this.repo3=repo3;
        this.repo4=repo4;
        /////////////mesagerie();
        //relatii();
    }

    private void mesagerie() {
        Iterable<Message> lst=repo3.findAll();
        for(Message m:lst)
        {
            Utilizator ut=m.getFrom();
            Utilizator ut2=repo.findOne(ut.getId());
            if(ut2!=null) {
                ut.setFirstName(ut2.getFirstName());
                ut.setLastName(ut2.getLastName());
            }

            List<Utilizator> lst2=m.getTo();
            for(Utilizator U:lst2)
            {
                Utilizator ut3=U;
                Utilizator ut4=repo.findOne(ut.getId());
                if(ut4!=null) {
                    ut3.setFirstName(ut4.getFirstName());
                    ut3.setLastName(ut4.getLastName());
                }
            }
        }
    }

    //returneaza cel mai mare id +1
    public int maxId()
    {
        Iterable<Utilizator>lst=getAll();
        int ma=0;
        for(Utilizator ut:lst)
        {
            if(ut.getId().intValue()>ma)
                ma=ut.getId().intValue();
        }

        Iterable<Cerere>lst2=repo4.findAll();
        for(Cerere ut:lst2)
        {
            if(ut.getSender().intValue()>ma)
                ma=ut.getSender().intValue();

            if(ut.getRecv().intValue()>ma)
                ma=ut.getRecv().intValue();
        }

        Iterable<Message>lst3=repo3.findAll();
        for(Message ut:lst3)
        {
            if(ut.getFrom().getId().intValue()>ma)
                ma=ut.getFrom().getId().intValue();

            for(Utilizator ut2:ut.getTo())
            {
                if(ut2.getId().intValue()>ma)
                    ma=ut2.getId().intValue();
            }
        }


        return ma+1;
    }


    /*
    * salveaza Utilizator messageTask in repo-ul pt utilizatori
    * si valideaza utilizatorul
    * */
    public Utilizator addUtilizator(Utilizator messageTask) {
        messageTask.setId(new Long(maxId()));
        valid.validate(messageTask);
        Utilizator task = repo.save(messageTask);
        return task;
    }

    /*
    * returneaza lista utilizatorilor
    * */
    public Iterable<Utilizator> getAll(){
        return repo.findAll();
    }


    /*
    * id-long
    * retunreaza utilizatorul cu acest id
    * arunca Service exceptie daca nu se gaseste
    * */
    public Utilizator findOne(Long id) throws ServiceException
    {
        Utilizator ut=repo.findOne(id);
        if(ut==null)
            throw new ServiceException("nu se gaseste acest id");
        return ut;
    }

    /*
    * realizeaza un dfs pe graful format de utilizatori si prietenii
    * nod Utilizator
    * multime(int) multimea in care se afla nodurile parcurse
    * */
    public void dfs(Utilizator nod,int multime)
    {
        if(map.containsKey(nod.getId()))
            return;
        map.put(nod.getId(),Integer.valueOf(multime));
        for(Utilizator i:nod.getFriends())
            dfs(findOne(i.getId()),multime);
        cnt++;
    }

    /*
    * este un dfs care extrage nodurile dint-ro multime
    * nod-utilizator
    * */
    public void dfs2(Utilizator nod)
    {
        if(map.containsKey(nod.getId()))
            return;
        sol.add(nod);
        map.put(nod.getId(),Integer.valueOf(1));
        for(Utilizator i:nod.getFriends())
            dfs2(findOne(i.getId()));
        cnt++;
    }

    /*
     * sterge utilizatorul cu id-ul id(Long)
     * sterge prieteniile legate de el
     * */
    public void delete(Long id)
    {
        Utilizator ut=repo.delete(id);



        for(Utilizator i:ut.getFriends())
        {
            Prietenie p=new Prietenie();
            p.setId(new Tuple(ut.getId(),i.getId()));
            Long f=p.getId().getLeft();
            Long g=p.getId().getRight();
            if(f>g)
            {
                Long aux=f;
                f=g;
                g=aux;
            }
            Tuple tt=new Tuple(f,g);
            p.setId(tt);
            repo2.delete(p.getId());
            i.removeFriend(ut);
        }
        Iterable<Message> lst2=repo3.findAll();
        List<Message> lst=new ArrayList<Message>();
        for(Message m:lst2)
            lst.add(m);
        int vf2=1;
        /*for(Message m:lst)
        {
            int vf=1;
            if(m.getFrom().getId()==id)
                vf=0;
            int lg=m.getTo().size();
            m.getTo().removeIf(x->(x.getId().equals(id)));
            if(lg>m.getTo().size()&&m.getTo().size()>0)
            {
                repo3.update(m);
                vf2=0;
            }
            if(m.getTo().size()==0)
                vf=0;
            if(vf==0) {
                repo3.delete(m.getId());
                vf2=0;
            }
        }*/

        /*Iterable<Cerere> cereri=repo4.findAll();

        for(Cerere c:cereri)
        {
            if(c.getSender()==id||c.getRecv()==id)
                repo4.delete(c.getId());
        }*/
        //if(vf2==0)
          //  repo3.reload();
    }

    /*
    * returneaza un int nr de componenete conexe
    * */
    public int componente() {
        int ret=0;
        map.clear();
        Iterable<Utilizator>sir=repo.findAll();
        for(Utilizator i:sir)
        {
            if(map.containsKey(i.getId())==false)
            {
                ret++;
                dfs(i,ret);
            }
        }
        return ret;
    }

    /*
    * nod-Utilizator
    * realizeaza un bk pt gasirea lantului cel mai lung pornind de la un nod
    * */
    public int bk(Utilizator nod)
    {
        int ret=1;
        Long f,g;
        //System.out.println(nod.getId());
        for(Utilizator i:nod.getFriends())
        {
            f=nod.getId();
            g=i.getId();
            if(f>g)
            {
                Long aux=f;
                f=g;
                g=aux;
            }
            Tuple<Long,Long> p=new Tuple(f,g);
            if(S.contains(p)==true)
                continue;
            S.add(p);
            int val=bk(findOne(i.getId()));
            if(val+1>ret)
                ret=val+1;
            S.remove(p);
        }
        return ret;
    }

    /*
    * se foloseste de bk pt a determina nodul din care incepe cel mai lung lant
    * si de dfs2 pt a returna lista nodurilor din componenta sa
    * */
    public ArrayList<Utilizator> maximala() {
        int ret=0,ma=0;
        Long rez=Long.parseLong("1");
        map.clear();
        Iterable<Utilizator>sir=repo.findAll();
        for(Utilizator i:sir)
        {
            S.clear();
            int val=bk(i);
            System.out.println(val);
            if(val>ma)
            {
                rez=i.getId();
                ma=val;
            }

        }
        System.out.println(ma);
        sol=new ArrayList<Utilizator>();
        map.clear();
        dfs2(repo.findOne(rez));
        return sol;
    }

    public List<Utilizator> getAllLst() {
        Iterable<Utilizator>users=getAll();
        List<Utilizator> lst= new ArrayList<>();
        for(Utilizator ut:users)
            lst.add(ut);
        return lst;
    }

    public Long findByEmail(String utilizator) {
        return repo.findByEmail(utilizator);
    }

    public Long findByUsername(String utilizator) {
        return repo.findByUsername(utilizator);
    }

    ///TO DO: add other methods
}
