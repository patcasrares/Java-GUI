package socialnetwork.service;

import socialnetwork.domain.PrietenDTO;
import socialnetwork.domain.Prietenie;
import socialnetwork.domain.Tuple;
import socialnetwork.domain.Utilizator;
import socialnetwork.domain.validators.ValidationException;
import socialnetwork.repository.Repository;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class PrietenieService  {
    private Repository<Long, Utilizator> repo;
    private Repository<Tuple<Long,Long>, Prietenie> repo2;
    private int cnt=0;
    private ArrayList<Utilizator> sol=new ArrayList<Utilizator>();
    HashMap<Long,Integer>map=new HashMap<Long,Integer>();

    Set<Tuple<Long,Long> > S=new HashSet<Tuple<Long,Long> >();

    public PrietenieService(Repository<Long, Utilizator> repo,Repository<Tuple<Long,Long>, Prietenie> repo2) {

        this.repo = repo;
        this.repo2= repo2;
        //relatii();
    }

    /*
    * returneaza prietenie
    * dintre cei 2 utilizatori
    * descrisi in perechea de id-uri
    * */
    public Prietenie findOne(Tuple<Long,Long>id)
    {
        Prietenie p=repo2.findOne(id);
        return p;
    }

    /*
     * actualizeaza relatiile de prietenie din fisier
     * */
    public void relatii()
    {
        Iterable<Prietenie> v=repo2.findAll();
        for(Prietenie p:v)
        {
            Utilizator A=repo.findOne(p.getId().getLeft());
            Utilizator B=repo.findOne(p.getId().getRight());
            A.addFriend(B);
            B.addFriend(A);
        }
    }





    /*
     * arunca ServiceException daca cei 2 utilizatori
     * descrisi in Prietenia p nu sunt amandoi existenti
     * salveaza prietenia si actualizeaza relatiile de prietenie altfel
     * */
    public void addPrietenie(Prietenie p) throws ServiceException {
        Long f=p.getId().getLeft();
        Long g=p.getId().getRight();
        if(f>g)
        {
            Long aux=f;
            f=g;
            g=aux;
        }
        Tuple tt=new Tuple(f,g);
        p.setId(tt);
        if(f==g)
        {
            throw new ServiceException("un utilizator nu poate fi prieten cu el insusi");
        }
        Utilizator A=repo.findOne(p.getId().getLeft());
        Utilizator B=repo.findOne(p.getId().getRight());
        if(A==null||B==null)
        {
            throw new ServiceException("nu se gasesc ambele id uri");
        }
        A.addFriend(B);
        B.addFriend(A);

        repo2.save(p);
    }


    /*
     * arunca ServiceException daca cei 2 utilizatori
     * descrisi in Prietenia p nu sunt amandoi existenti
     * sterge prietenia si actualizeaza relatiile de prietenie altfel
     * */
    public void removePrietenie(Prietenie p) throws ServiceException{
        Long f=p.getId().getLeft();
        Long g=p.getId().getRight();
        if(f>g)
        {
            Long aux=f;
            f=g;
            g=aux;
        }
        Tuple tt=new Tuple(f,g);
        p.setId(tt);
        Utilizator A=repo.findOne(p.getId().getLeft());
        Utilizator B=repo.findOne(p.getId().getRight());
        if(A==null||B==null)
        {
            throw new ServiceException("nu se gasesc ambele id uri");
        }
        A.removeFriend(B);
        B.removeFriend(A);
        repo2.delete(p.getId());
    }


    public List<PrietenDTO> prieteni(String id) {

        Predicate<PrietenDTO> pr= x->{
            return true;
        };
        return friendUser(id,pr);
        /*Utilizator ut=null;
        ut=repo.findOne(Long.parseLong(id));

        if(ut==null)
            throw new ServiceException("nu este acest id");

        return ut.getFriends().stream()
                .map(x->{

                    Long f=Long.parseLong(id);
            Long g=x.getId();
            if(f>g)
            {
                Long aux=f;
                f=g;
                g=aux;
            }
            Tuple tt=new Tuple(f,g);

            Prietenie p=repo2.findOne(tt);
            return ""+x.getId()+" | "+x.getFirstName()+" | "+x.getLastName()+" | "+p.getDate();
        })
                .collect(Collectors.toList());*/
    }

    public List<PrietenDTO> prieteni_luna(String id, int luna) {
        Predicate<PrietenDTO> pr= x->{
            return x.getData().getMonthValue()==luna;
          //return vf_luna(x.getData().toString(),luna);
        };
        return friendUser(id,pr);
        /*Utilizator ut=null;

        ut=repo.findOne(Long.parseLong(id));
        if(ut==null)
            throw new ServiceException("nu este acest id");

        return ut.getFriends().stream().map(x->{
            Long f=Long.parseLong(id);
            Long g=x.getId();
            if(f>g)
            {
                Long aux=f;
                f=g;
                g=aux;
            }
            Tuple tt=new Tuple(f,g);

            Prietenie p=repo2.findOne(tt);
            return ""+x.getId()+" | "+x.getFirstName()+" | "+x.getLastName()+" | "+p.getDate();

        })
                .filter(x->vf_luna(x,luna))
                .collect(Collectors.toList());

         */
    }

    public boolean vf_luna(String s,int luna)
    {
        for(int i=0;i<s.length();i++)
        {
            if(s.charAt(i)=='-')
            {
                int f=s.charAt(i+1);
                f-='0';
                int g=s.charAt(i+2);
                g-='0';
                f=f*10+g;
                System.out.println(f+" "+luna);
                return (f==luna);
            }
        }
        return false;
    }

    public List<PrietenDTO> friendUser(String id,Predicate<PrietenDTO> pr)
    {
        Utilizator ut=null;

        ut=repo.findOne(Long.parseLong(id));
        if(ut==null)
            throw new ServiceException("nu este acest id");

        return ut.getFriends().stream().map(x->{
            Long f=Long.parseLong(id);
            Long g=x.getId();
            if(f>g)
            {
                Long aux=f;
                f=g;
                g=aux;
            }
            Tuple tt=new Tuple(f,g);

            Prietenie p=repo2.findOne(tt);
            return new PrietenDTO(x,p.getDate());
            //return ""+x.getId()+" | "+x.getFirstName()+" | "+x.getLastName()+" | "+p.getDate();

        })
                .filter(pr)
                .collect(Collectors.toList());
    }

}
