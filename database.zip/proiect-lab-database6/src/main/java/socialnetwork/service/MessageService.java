package socialnetwork.service;

import socialnetwork.domain.*;
import socialnetwork.domain.validators.MessageValidator;
import socialnetwork.domain.validators.UtilizatorValidator;
import socialnetwork.repository.Repository;
import socialnetwork.repository.file.MessageFile;
import socialnetwork.repository.file.UtilizatorFile;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MessageService {
    private Repository<Long,Message> repo;
    private MessageValidator valid = new MessageValidator();
    private Repository<Long,Utilizator> repo_u;
    public MessageService(Repository<Long,Message> repo,Repository<Long,Utilizator> repo_u)
    {
        this.repo=repo;
        this.repo_u=repo_u;
    }

    /*
     * salveaza Utilizator messageTask in repo-ul pt utilizatori
     * si valideaza utilizatorul
     * */
    public Message addMessage(Message messageTask) {
        valid.validate(messageTask);
        messageTask.setId(IdMaxim());
        Message task = repo.save(messageTask);
        System.out.println("sfsd");
        return task;
    }

    private Long IdMaxim() {
        Long ma=new Long(1);
        Iterable<Message> lst= repo.findAll();
        for(Message m: lst)
        {
            if(ma < m.getId())
                ma=m.getId();
        }
        ma=new Long(ma.intValue()+1);
        return ma;
    }


    public void addReply(Long id_u, Long id_m, String msg,int type) throws ServiceException {
        Utilizator ut=repo_u.findOne(id_u);
        Message mes=repo.findOne(id_m);
        if(ut==null )
            throw new ServiceException("nu este acest utilizator");
        if(mes==null )
            throw new ServiceException("nu este acest mesaj");
        List<Utilizator> lst=new ArrayList<Utilizator>();
        Utilizator F=mes.getFrom();
        F=repo_u.findOne(F.getId());
        if(F!=null)
            lst.add(F);
        if(type==1)
        for(Utilizator U:mes.getTo())
        {
            //System.out.println(U.getId());
            if(U.getId()==id_u)
                continue;
            F=repo_u.findOne(U.getId());
            if(F==null)
                continue;
            lst.add(F);
        }
        ReplyMessage reply=new ReplyMessage(ut,lst,msg);

        reply.setId(IdMaxim());
        reply.setReply(mes);
        valid.validate(reply);
        repo.save(reply);
    }

    public List<Message> afisare(Long id1,Long id2)
    {
        Iterable<Message> zz= repo.findAll();
        List<Message>lst=new ArrayList<Message>();
        for(Message m:zz)
        {
            System.out.println(m.getId());
            int vf1=0,vf2=0;
            Utilizator from=m.getFrom();
            if(from.getId().equals(id1))
                vf1=1;
            if(from.getId().equals(id2))
                vf2=1;

            for(Utilizator ut:m.getTo())
            {
                System.out.println(ut.getId()+" "+id2);
                if(ut.getId().equals(id1))
                    vf1=1;
                if(ut.getId().equals(id2))
                    vf2=1;
            }

            if(!from.getId().equals(id1)&&!from.getId().equals(id2))
                vf1=0;

            System.out.println(vf1+" "+vf2);
            if(vf1==1&&vf2==1)
                lst.add(m);
        }
        return lst.stream()
                .sorted((i1,i2)->i1.getData().compareTo(i2.getData()))
                .collect(Collectors.toList());

    }
}
