package socialnetwork.repository.database;

import socialnetwork.domain.Cerere;
import socialnetwork.domain.Message;
import socialnetwork.domain.Tuple;
import socialnetwork.domain.Utilizator;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class CerereDbRepository extends RepoBaza<Tuple<Long,Long>, Cerere> {

    //String select="SELECT * from mesaje";
    public CerereDbRepository(String url, String username, String password)
    {
        super("SELECT * from cereri",
                "INSERT INTO cereri" +
                        "  (Emitator, receptor, status, data) VALUES " +
                        " (?, ?, ?, ?);",
                "DELETE FROM cereri WHERE emitator = ? AND receptor=? ",
                "UPDATE cereri " +
                        "SET  status= ?"+
                        "WHERE emitator=? AND receptor=?",url, username, password,
                "select * from cereri "+"where emitator=? and receptor=?" //or (receptor=? and emitator=?))"
        );
    }



    @Override
    protected void patern(PreparedStatement statement, Tuple<Long, Long> id) {
        try {
            Long f = id.getLeft();
            Long g = id.getRight();
            statement.setInt(1, f.intValue());
            statement.setInt(2, g.intValue());

            /////////////statement.setInt(3, f.intValue());
            ///////////statement.setInt(4, g.intValue());
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    @Override
    public Cerere parsez(ResultSet resultSet) {
        Cerere m=null;
        try {
            Long id1 = resultSet.getLong("Emitator");
            Long id2 = resultSet.getLong("receptor");
            String status = resultSet.getString("status");
            String data = resultSet.getString("data");
            m=new Cerere(id1,id2);
            //System.out.println("sdjskfs");
            m.setDate(LocalDateTime.parse(data));
            m.setStatus(status);

        }
        catch(Exception e)
        {
            System.out.println(e);
        }


        return m;
    }

    @Override
    protected void inserare(PreparedStatement preparedStatement, Cerere entity) {
        try
        {
            preparedStatement.setInt(1,entity.getSender().intValue());
            preparedStatement.setInt(2,entity.getRecv().intValue());
            preparedStatement.setString(3,entity.getStatus());
            preparedStatement.setString(4,entity.getDate().toString());

        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    private String lista(List<Utilizator> to) {
        List<Long>lst=new ArrayList<>();
        for(Utilizator ut:to)
        {
            lst.add(ut.getId());
        }
        return ""+lst;
    }

    @Override
    public void modificare(PreparedStatement preparedStatement, Cerere entity) {
        try
        {
            preparedStatement.setString(1,entity.getStatus());
            preparedStatement.setInt(2,entity.getSender().intValue());
            preparedStatement.setInt(3,entity.getRecv().intValue());
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

}
