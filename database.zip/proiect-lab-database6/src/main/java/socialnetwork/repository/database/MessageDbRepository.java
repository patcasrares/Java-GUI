package socialnetwork.repository.database;

import socialnetwork.domain.Message;
import socialnetwork.domain.ReplyMessage;
import socialnetwork.domain.Utilizator;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class MessageDbRepository extends RepoBaza<Long, Message> {

    //String select="SELECT * from mesaje";
    public MessageDbRepository(String url, String username, String password)
    {
        super("SELECT * from mesaj",
                "INSERT INTO mesaj" +
                        "  (id, expeditor,data,mesaj,reply) VALUES " +
                        " (?, ?, ? ,?,?);",
                "DELETE FROM mesaj WHERE ID = ? ",
                "UPDATE mesaj " +
                        "SET  destinatari= ?"+
                        "WHERE id=?",url, username, password,
                "select * from mesaj "+"where id=?"
                );
    }



    @Override
    protected void patern(PreparedStatement statement, Long id) {
        try {

            statement.setInt(1, id.intValue());
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    @Override
    public Message parsez(ResultSet resultSet) {
        Message m=null;
        try {
            Long id = resultSet.getLong("id");
            Long From = resultSet.getLong("expeditor");
            //String To = resultSet.getString("destinatari");

            Utilizator f=new Utilizator("Aa","Bb");
            f.setId(From);

            String s="";
            List<Utilizator> lst=new ArrayList<Utilizator>();
            String cauta="select * from destinatari "+"where id_mesaj=?";
            try (Connection connection = DriverManager.getConnection(getUrl(), getUsername(), getPassword());
                 PreparedStatement statement = connection.prepareStatement(cauta))
                  {
                      statement.setInt(1,id.intValue());
                      ResultSet rst = statement.executeQuery();

                while (rst.next()) {
                /*Long id = resultSet.getLong("id");
                String firstName = resultSet.getString("nume");
                String lastName = resultSet.getString("prenume");*/

                   Long d=rst.getLong("id_utiliz");
                   Utilizator ut=new Utilizator("Aa","Bb");
                   ut.setId(d);
                   lst.add(ut);

                }
                //return entities.values();
            } catch (SQLException e) {
                e.printStackTrace();
            }


            s=resultSet.getString("data");
            LocalDateTime data = LocalDateTime.parse(s);
            s=resultSet.getString("mesaj");
            m=new Message(f,lst,s,data);
            m.setId(id);
            String repl=resultSet.getString("reply");
            if(!repl.equals("0")) {
                ReplyMessage m2=new ReplyMessage(f,lst,s,data);
                m2.setReply(findOne(Long.parseLong(repl)));
                m2.setId(id);
                m=m2;
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }


        return m;
    }

    @Override
    protected void inserare(PreparedStatement preparedStatement, Message entity) {
        try
        {
            preparedStatement.setInt(1,entity.getId().intValue());
            preparedStatement.setInt(2,entity.getFrom().getId().intValue());

            //preparedStatement.setString(3,lista(entity.getTo()));
            preparedStatement.setString(3,entity.getData().toString());
            preparedStatement.setString(4,entity.getMessage());

            add_destinatari(entity);
            if(entity.getReply()==null)
                preparedStatement.setInt(5,0);
            else
                preparedStatement.setInt(5,entity.getReply().getId().intValue());
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    private void add_destinatari(Message entity) {
        String ins="INSERT INTO destinatari" +
                "  (id_mesaj,id_utiliz) VALUES " +
                " (?, ?);";
        try (Connection connection = DriverManager.getConnection(getUrl(), getUsername(), getPassword()))
             {


                 List<Utilizator> lst=entity.getTo();
                 for(Utilizator ut:lst)
                 {
                     Long f=entity.getId();
                     Long g=ut.getId();
                     PreparedStatement statement = connection.prepareStatement(ins);
                     statement.setInt(1,f.intValue());
                     statement.setInt(2,g.intValue());
                     statement.executeUpdate();
                 }
            //return entities.values();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private String lista(List<Utilizator> to) {
        List<Long>lst=new ArrayList<>();
        for(Utilizator ut:to)
        {
            lst.add(ut.getId());
        }
        return ""+lst;
    }




}
