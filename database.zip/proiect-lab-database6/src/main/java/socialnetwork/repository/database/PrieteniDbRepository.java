package socialnetwork.repository.database;

import socialnetwork.domain.Prietenie;
import socialnetwork.domain.Tuple;
import socialnetwork.domain.Utilizator;
import socialnetwork.domain.validators.Validator;
import socialnetwork.repository.RepoException;
import socialnetwork.repository.Repository;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;

public class PrieteniDbRepository implements Repository<Tuple<Long,Long>, Prietenie> {
    //Map<Tuple<Long,Long>, Prietenie> entities=null;


    private String url;
    private String username;
    private String password;
    private Validator<Prietenie> validator;
    private String cauta="select * from prieteni "+"where stanga=? and dreapta=?";
    private static final String INSERT_FRIENDS_SQL = "INSERT INTO prieteni" +
            "  (stanga, dreapta, data) VALUES " +
            " (?, ?, ?);";

    private static final String DELETE_FRIENDS_SQL = "DELETE FROM prieteni WHERE stanga = ? and dreapta = ? ";

    public PrieteniDbRepository(String url, String username, String password, Validator<Prietenie> validator) {
        this.url = url;
        this.username = username;
        this.password = password;
        this.validator = validator;
        findAll();
    }

    /*
    * returneaza prietenia al arui Id este aLong
    * */
    @Override
    public Prietenie findOne(Tuple<Long,Long> aLong) {

        Prietenie prietenie=null;
        try (Connection connection = DriverManager.getConnection(url, username, password);
        )
        {
            PreparedStatement statement = connection.prepareStatement(cauta);
            statement.setInt(1, aLong.getLeft().intValue());
            statement.setInt(2, aLong.getRight().intValue());
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
               // Long id = resultSet.getLong("id");
                //String firstName = resultSet.getString("nume");
                //String lastName = resultSet.getString("prenume");
                Long id1 = resultSet.getLong("stanga");
                Long id2 = resultSet.getLong("dreapta");
                String data=resultSet.getString("data");
                Tuple<Long,Long> per=new Tuple<Long,Long>(id1,id2);
                prietenie = new Prietenie();
                prietenie.setId(per);
                prietenie.setDate(LocalDateTime.parse(data));

            }
            //return users;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return prietenie;
        //return entities.get(aLong);
    }

    //extrage prieteniile din baza de date si returneaza lista acestora
    @Override
    public Iterable<Prietenie> findAll() {
        //if(entities!=null)
        //    return entities.values();
        Map<Tuple<Long,Long>, Prietenie>entities=new HashMap<Tuple<Long,Long>, Prietenie>();
        //Set<Prietenie> prietenie = new HashSet<>();
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement("SELECT * from prieteni");
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                Long id1 = resultSet.getLong("stanga");
                Long id2 = resultSet.getLong("dreapta");
                String data=resultSet.getString("data");
                Tuple<Long,Long> per=new Tuple<Long,Long>(id1,id2);
                Prietenie prieten = new Prietenie();
                prieten.setId(per);
                prieten.setDate(LocalDateTime.parse(data));
                entities.put(per,prieten);
                //prietenie.add(prieten);
            }
            return entities.values();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return entities.values();
    }

    //salveaza o prietenie arunca eroare daca exista deja
    //arunca DatabaseException
    @Override
    public Prietenie save(Prietenie entity)throws DatabaseException {

        if(findOne(entity.getId())!=null)
        {
            throw new DatabaseException("este deja acest id");
        }
        int A=entity.getId().getLeft().intValue();
        int B=entity.getId().getRight().intValue();
        if(A>B)
        {
            int C=A;
            A=B;
            B=C;
        }
        String C=entity.getDate().toString();

        try (Connection connection = DriverManager.getConnection(url, username, password);

             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_FRIENDS_SQL)) {
            preparedStatement.setInt(1, A);
            preparedStatement.setInt(2, B);
            preparedStatement.setString(3, C);

            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            preparedStatement.executeUpdate();
        } catch (Exception e) {

            // print SQL exception information
            System.out.println(e);
        }
        return null;
    }

    //sterge o prietenie cu id-ul id(Tuple<Long,Long> da eroare daca nu este
    //arunca DatabaseException
    @Override
    public Prietenie delete(Tuple<Long,Long> id) throws DatabaseException {
        if(findOne(id)==null)
            throw new DatabaseException("nu este acest id");
        Prietenie ret=findOne(id);

        int A=id.getLeft().intValue();
        int B=id.getRight().intValue();
        try (Connection connection = DriverManager.getConnection(url, username, password);

             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_FRIENDS_SQL)) {
            preparedStatement.setInt(1, A);
            preparedStatement.setInt(2, B);

            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            preparedStatement.executeUpdate();
        } catch (Exception e) {

            // print SQL exception information
            System.out.println(e);
        }
        return ret;
    }

    @Override
    public Prietenie update(Prietenie entity) {
        return null;
    }

    @Override
    public Tuple<Long,Long> findByEmail(String str)
    {
        throw new UnsupportedOperationException();
    }


    @Override
    public Tuple<Long,Long> findByUsername(String str)
    {
        throw new UnsupportedOperationException();
    }
}
