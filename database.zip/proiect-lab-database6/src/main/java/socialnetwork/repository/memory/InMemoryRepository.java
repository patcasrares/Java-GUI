package socialnetwork.repository.memory;

import socialnetwork.domain.Entity;
import socialnetwork.domain.Prietenie;
import socialnetwork.domain.validators.Validator;
import socialnetwork.repository.RepoException;
import socialnetwork.repository.Repository;

import java.util.HashMap;
import java.util.Map;

public class InMemoryRepository<ID, E extends Entity<ID>> implements Repository<ID,E> {

    private Validator<E> validator;
    Map<ID,E> entities;

    public void addPrietenie(Prietenie p) {
        //repo.addPrietenie(p);
    }

    public void removePrietenie(Prietenie p) {
        //repo.addPrietenie(p);
    }

    public InMemoryRepository(Validator<E> validator) {
        this.validator = validator;
        entities=new HashMap<ID,E>();
    }

    @Override
    public E findOne(ID id){
        if (id==null)
            throw new IllegalArgumentException("id must be not null");
        return entities.get(id);
    }

    @Override
    public Iterable<E> findAll() {
        return entities.values();
    }

    /*
    * arunca RepoException daca este deja aceasta entitate
    * si IllegalRgument daca entitatea este null
    * */
    @Override
    public E save(E entity) throws RepoException {
        if (entity==null)
            throw new IllegalArgumentException("entity must be not null");
        validator.validate(entity);
        if(entity.getId()!=null)
            if(entities.get(entity.getId()) != null) {
                throw new RepoException("este deja acest id");
                //return entity;
            }
            else entities.put(entity.getId(),entity);
        return null;
    }

    /*
    * sterge entitatea cu acel id
    * arunca RepoException daca nu exista entitate cu acest id
    * */
    @Override
    public E delete(ID id) throws RepoException {
        if(entities.get(id)==null)
            throw new RepoException("nu este acest id");
        E ret=entities.get(id);
        entities.remove(id);
        return ret;
    }

    /*
    * modifica o entitate
    *
    * */
    @Override
    public E update(E entity) {

        if(entity == null)
            throw new IllegalArgumentException("entity must be not null!");
        validator.validate(entity);

        entities.put(entity.getId(),entity);

        if(entities.get(entity.getId()) != null) {
            entities.put(entity.getId(),entity);
            return null;
        }
        return entity;

    }

    @Override
    public ID findByEmail(String str)
    {
        throw new UnsupportedOperationException();
    }


    @Override
    public ID findByUsername(String str)
    {
        throw new UnsupportedOperationException();
    }

}
