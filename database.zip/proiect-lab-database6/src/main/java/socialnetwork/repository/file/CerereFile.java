package socialnetwork.repository.file;

import socialnetwork.domain.Cerere;
import socialnetwork.domain.Prietenie;
import socialnetwork.domain.Tuple;
import socialnetwork.domain.Utilizator;
import socialnetwork.domain.validators.UtilizatorValidator;
import socialnetwork.domain.validators.Validator;

import java.io.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CerereFile extends AbstractFileRepository<Tuple<Long,Long>, Cerere> {

    public CerereFile(String fileName, Validator<Cerere> validator)
    {
        super(fileName,validator);
    }

    @Override
    public Cerere extractEntity(List<String> attributes) {

        Cerere c=new Cerere(Long.parseLong(attributes.get(0)),Long.parseLong(attributes.get(1)));
        c.setStatus(attributes.get(2));
        return c;
    }

    @Override
    protected String createEntityAsString(Cerere entity) {
        return ""+entity.getId().getLeft()+";"+entity.getId().getRight()+";"+entity.getStatus();

    }
}