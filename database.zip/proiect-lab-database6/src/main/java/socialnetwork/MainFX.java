package socialnetwork;


import controller.LoginController;
import controller.SideBarController;
import controller.UserController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import socialnetwork.config.ApplicationContext;
import socialnetwork.domain.*;
import socialnetwork.domain.validators.PrietenieValidator;
import socialnetwork.domain.validators.UtilizatorValidator;
import socialnetwork.repository.Repository;
import socialnetwork.repository.database.CerereDbRepository;
import socialnetwork.repository.database.MessageDbRepository;
import socialnetwork.repository.database.PrieteniDbRepository;
import socialnetwork.repository.database.UtilizatorDbRepository;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;

public class MainFX extends Application {
    private UtilizatorService srvU=null;
    private PrietenieService srvP=null;
    private MessageService srvM=null;
    private CerereService srvC=null;
    private GUI control=null;


    public void setez()
    {
        final String url = ApplicationContext.getPROPERTIES().getProperty("database.socialnetwork.url");
        final String username= ApplicationContext.getPROPERTIES().getProperty("databse.socialnetwork.username");
        final String pasword= ApplicationContext.getPROPERTIES().getProperty("database.socialnetwork.pasword");

        Repository<Long, Utilizator> repoU =
                new UtilizatorDbRepository(url,username, pasword,  new UtilizatorValidator());
        Repository<Tuple<Long,Long>, Prietenie> repoP =
                new PrieteniDbRepository(url,username, pasword,  new PrietenieValidator());

        Repository<Long, Message> repoM =
                new MessageDbRepository(url,username, pasword);

        Repository<Tuple<Long,Long>, Cerere> repoC=
                new CerereDbRepository(url,username, pasword);

        this.srvU=new UtilizatorService(repoU,repoP,repoM,repoC);
        this.srvP=new PrietenieService(repoU,repoP);
        this.srvM=new MessageService(repoM,repoU);
        this.srvC=new CerereService(repoU,repoP,repoC);
    }



    @Override
    public void start(Stage primaryStage) throws Exception {
        //Declaratii variabile
        setez();

        FXMLLoader loader=new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/Login.fxml"));
        Pane root;
        root = loader.load();

        LoginController ctr = loader.getController();
        ctr.initial(srvU,srvP,srvM,srvC);
        primaryStage.setScene(new Scene(root));
        primaryStage.setTitle("Hello World");
        primaryStage.show();

        /*FXMLLoader loader=new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/sidebar.fxml"));
        Pane root;
        root = loader.load();
        SideBarController sbc = loader.getController();
        sbc.initial(5L,srvU,srvP,srvM,srvC);

        //UserController ctrl=loader.getController();
        //ctrl.setSrv(srvU,srvP,srvM,srvC);

        primaryStage.setScene(new Scene(root));
        primaryStage.setTitle("Hello World");
        primaryStage.show();
        */

        /*FXMLLoader loader=new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/UserView.fxml"));
        AnchorPane root=loader.load();

        UserController ctrl=loader.getController();
        ctrl.setSrv(srvU,srvP,srvM,srvC);

        primaryStage.setScene(new Scene(root));
        primaryStage.setTitle("Hello World");
        primaryStage.show();
        */








        /*HBox hbox = new HBox();

        Scene scene = new Scene(hbox);
        control = new GUI(hbox,srvU,srvP,srvC);
        primaryStage.setScene(scene);
        primaryStage.show();*/
        //stage.show();
    }
    public static void main(String[] args) {
        launch();
    }
}