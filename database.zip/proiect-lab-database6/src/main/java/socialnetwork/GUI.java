package socialnetwork;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import socialnetwork.domain.Cerere;
import socialnetwork.domain.Prietenie;
import socialnetwork.domain.Tuple;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.CerereService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class GUI {

    private TableView tableView;
    private TableView tablePrietenii = new TableView();
    ObservableList<Utilizator> modelUser = FXCollections.observableArrayList();
    ObservableList<Utilizator> modelPrieten = FXCollections.observableArrayList();
    ObservableList<Cerere> modelCereri = FXCollections.observableArrayList();
    private HBox hbox;
    UtilizatorService srvU;
    PrietenieService srvP;
    private TextField textField;
    private Utilizator U;
    private VBox caut;
    private TableView cereri;
    private Button btnC;
    private CerereService srvC;

    private TextField text_FirstName = new TextField();
    private TextField text_LastName = new TextField();
    private HBox caut_FirstName = new HBox();
    private HBox caut_LastName = new HBox();
    private Button btn_addP;


    public GUI(HBox hbox, UtilizatorService srvU, PrietenieService srvP,CerereService srvC) {
        this.hbox = hbox;
        this.srvU = srvU;
        this.srvP = srvP;
        this.srvC = srvC;
        initializ();
    }

    private void handlePrieten() {
        Predicate<Utilizator> p1 = ut -> ut.getFirstName().startsWith(text_FirstName.getText());
        Predicate<Utilizator> p2 = n -> n.getLastName().startsWith(text_LastName.getText());

        List<Utilizator> lst = new ArrayList<>();

        modelPrieten.setAll(srvU.getAllLst()
                .stream()
                .filter(p1.and(p2))
                .collect(Collectors.toList()));
    }

    private void initializ() {

        text_FirstName.textProperty().addListener(c -> handlePrieten());
        text_LastName.textProperty().addListener(c -> handlePrieten());
        caut_FirstName.getChildren().add(new Label("First Name"));
        caut_FirstName.getChildren().add(text_FirstName);
        caut_LastName.getChildren().add(new Label("Last Name"));
        caut_LastName.getChildren().add(text_LastName);
        tableView = new TableView();

        TableColumn<Utilizator, Long> column1 = new TableColumn<>("Id");
        column1.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Utilizator, Long> column12 = new TableColumn<>("Id");
        column12.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Utilizator, String> column2 = new TableColumn<>("First Name");
        column2.setCellValueFactory(new PropertyValueFactory<>("firstName"));

        TableColumn<Utilizator, String> column22 = new TableColumn<>("First Name");
        column22.setCellValueFactory(new PropertyValueFactory<>("firstName"));


        TableColumn<Utilizator, String> column3 = new TableColumn<>("Last Name");
        column3.setCellValueFactory(new PropertyValueFactory<>("lastName"));

        TableColumn<Utilizator, String> column32 = new TableColumn<>("Last Name");
        column32.setCellValueFactory(new PropertyValueFactory<>("lastName"));


        tableView.getColumns().add(column1);
        tableView.getColumns().add(column2);
        tableView.getColumns().add(column3);

        tablePrietenii.getColumns().add(column12);
        tablePrietenii.getColumns().add(column22);
        tablePrietenii.getColumns().add(column32);

        tablePrietenii.setItems(modelPrieten);

        Utilizator ut1=new Utilizator("John", "Doe");
        ut1.setId(2L);
        Utilizator ut2=new Utilizator("Jane", "Denvers");
        ut2.setId(1L);
        tableView.getItems().add(ut1);
        tableView.getItems().add(ut2);

        tableView.setItems(modelUser);
        tableView.setMaxSize(500,500);

        //VBox vbox = new VBox(tableView);
        //HBox vbox= new HBox();
        //VBox vbox = new VBox();

        caut = new VBox();

        textField = new TextField();
        Button btn = new Button("Delete");
        Button btnAddC = new Button("Cereri");

        Label label = new Label("id Utilizator");
        HBox hb = new HBox();
        hb.getChildren().addAll(label,textField);
        caut.getChildren().addAll(hb,btn);
        textField.textProperty().addListener(c -> handleUser());
        hbox.getChildren().addAll(tableView, caut);

        btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    Utilizator selected = (Utilizator) tableView.getSelectionModel().getSelectedItem();
                    System.out.println(selected);   //srvU.delete(selected.getId());
                    U.removeFriend(selected);
                    Prietenie p = new Prietenie();
                    p.setId(new Tuple<Long, Long>(U.getId(), selected.getId()));
                    srvP.removePrietenie(p);
                    modelUser.setAll(U.getFriends());
                    MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "deletion", "prietenie a fost stearsa");
                }
                catch(Exception e)
                {
                    MessageAlert.showErrorMessage(null,"tb selectat utilizatorul si prietenul");
                }
            }
        });

        btnAddC.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                del_prietenii();
                add_requests();
            }
        });

        Button addPrieteni = new Button("Cauta Prieteni");
        cereri= new TableView();
        init_cereri();
        btnC = new Button("Remove Prietenii");
        btnC.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                //a_requests();
                del_requests();
            }
        });

        addPrieteni.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                //a_requests();
                del_requests();
                add_prietenii();
            }
        });
        //add_cereri();
        caut.getChildren().add(btnAddC);
        caut.getChildren().add(addPrieteni);

        btn_addP = new Button("Adauga");
        btn_addP.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Utilizator selected=(Utilizator) tablePrietenii.getSelectionModel().getSelectedItem();
                //Cerere cerere = new Cerere(U.getId(), selected.getId());
                System.out.println("dfsfgtrgefwbtgrfe");
                try
                {
                    boolean b=srvC.adaug(U.getId(), selected.getId());
                    if(b==true)
                    MessageAlert.showMessage(null,Alert.AlertType.INFORMATION,"add friend","ai acceptat prietenia");
                    else
                        MessageAlert.showMessage(null,Alert.AlertType.INFORMATION,"add friend","ai trimis cererea");
                    U=srvU.findOne(U.getId());
                    modelUser.setAll(U.getFriends());
                }
                catch (Exception e)
                {
                    MessageAlert.showErrorMessage(null,e.toString());
                    //System.out.println(e);
                }

                modelUser.setAll(U.getFriends());

            }
        });

    }



    private void add_prietenii() {
        try
        {
            caut.getChildren().add(caut_FirstName);
            caut.getChildren().add(caut_LastName);
            caut.getChildren().add(btn_addP);
            caut.getChildren().add(tablePrietenii);
            List<Utilizator>lst= new ArrayList<>();
            Iterable<Utilizator> users = srvU.getAll();
            for(Utilizator ut:users)
                lst.add(ut);
            modelPrieten.setAll(lst);
        }catch(Exception e)
        {

        }
    }

    private void del_prietenii() {
        try
        {
            caut.getChildren().remove(caut_FirstName);
            caut.getChildren().remove(caut_LastName);
            caut.getChildren().remove(btn_addP);
            caut.getChildren().remove(tablePrietenii);

        }catch(Exception e)
        {

        }
    }

    private void init_cereri() {
        //TableColumn<Utilizator, Long> column1 = new TableColumn<>("Sender");
        //column1.setCellValueFactory(new PropertyValueFactory<>("S"));

        TableColumn<Cerere, Long> column2 = new TableColumn<>("Recv");
        column2.setCellValueFactory(new PropertyValueFactory<>("Recv"));


        TableColumn<Cerere, String> column3 = new TableColumn<>("Status");
        column3.setCellValueFactory(new PropertyValueFactory<>("Status"));

        TableColumn<Cerere, String> column4 = new TableColumn<>("Date");
        column4.setCellValueFactory(new PropertyValueFactory<>("Date"));
        cereri.getColumns().add(column2);
        cereri.getColumns().add(column3);
        cereri.getColumns().add(column4);

        cereri.setItems(modelCereri);
    }

    private void del_requests() {

        caut.getChildren().remove(btnC);
        caut.getChildren().remove(cereri);
    }

    private void add_requests() {
        try {
            caut.getChildren().add(cereri);
            caut.getChildren().add(btnC);
        }
        catch(Exception e)
        {

        }
        //caut.getChildren().remove(cereri);
    }

    private void handleUser() {
        try
        {
            System.out.println(13123);
            Long id = Long.parseLong(textField.getText());
            Utilizator ut = srvU.findOne(id);
            System.out.println(ut);
            U=ut;
            System.out.println(ut.getFriends());
            modelUser.setAll(ut.getFriends());
            List<Cerere> lst = new ArrayList<Cerere>();
            System.out.println("sdfsdf");

            System.out.println("sdfsdf");
            modelCereri.setAll(srvC.cereri_trimise(U.getId()));
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
}
